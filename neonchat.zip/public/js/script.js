const socket = io();
const chatBox = document.getElementById('chat-box');
const chatInput = document.getElementById('chat-input');
const sendBtn = document.getElementById('send-btn');
const fileInput = document.getElementById('file-input');

socket.on('chatMessage', (data) => {
  const message = `<p><strong>User ${data.id}:</strong> ${data.msg}</p>`;
  chatBox.innerHTML += message;
  chatBox.scrollTop = chatBox.scrollHeight;
});

sendBtn.addEventListener('click', () => {
  if (chatInput.value.trim() !== "") {
    socket.emit('chatMessage', chatInput.value);
    chatInput.value = '';
  }
});

fileInput.addEventListener('change', (e) => {
  const file = e.target.files[0];
  if (file) {
    const formData = new FormData();
    formData.append('file', file);

    fetch('/upload', { method: 'POST', body: formData })
      .then(res => res.json())
      .then(data => {
        socket.emit('chatMessage', `Uploaded: ${data.filePath}`);
      });
  }
});