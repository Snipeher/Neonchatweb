require('dotenv').config();
const express = require('express');
const app = express();
const server = require('http').createServer(app);
const io = require('socket.io')(server);
const multer = require('multer');
const path = require('path');

const PORT = process.env.PORT || 3000;

app.use(express.static(path.join(__dirname, '../public')));

const storage = multer.diskStorage({
  destination: path.join(__dirname, '../uploads'),
  filename: (req, file, cb) => {
    cb(null, Date.now() + path.extname(file.originalname));
  }
});
const upload = multer({ storage });

io.on('connection', (socket) => {
  console.log('New user connected:', socket.id);
  socket.on('chatMessage', (msg) => {
    io.emit('chatMessage', { id: socket.id, msg });
  });
  socket.on('disconnect', () => {
    console.log('User disconnected:', socket.id);
  });
});

app.post('/upload', upload.single('file'), (req, res) => {
  res.json({ filePath: `/uploads/${req.file.filename}` });
});

server.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});